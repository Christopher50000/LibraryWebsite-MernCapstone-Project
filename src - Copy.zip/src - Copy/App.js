
//import './App.css';
import ImageComponent from './ImageComponent.js';
import { Home } from './Routertest';
import Routertest from './Routertest.js'

function App() {
  return (
    
    <div>
      
       <Routertest />
       </div>



       
    
  
  );
}

export default App;


/*
   <div class="background">
        <ImageComponent />
      </div>
*/